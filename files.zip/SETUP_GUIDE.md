# JobPilot — Complete Setup Guide
## Get your automated job application system running for FREE

---

## What you'll have when done
A private web app that:
1. **Fetches** job listings from Google Jobs + company job boards daily
2. **Scores** each listing with AI to show you only relevant matches
3. **Lets you approve or skip** jobs from a clean dashboard
4. **Generates tailored resume + cover letter PDFs** for every job you approve — using Claude AI

**Total cost: $0/month** (using free tiers of all services)

---

## Step 1 — Create a GitHub account (skip if you have one)
1. Go to **github.com**
2. Click **Sign up** and create a free account
3. Verify your email

---

## Step 2 — Upload the project to GitHub

1. Go to **github.com** and click the **+** button → **New repository**
2. Name it `jobpilot`, set it to **Private**, click **Create repository**
3. You'll see a page with setup instructions — ignore them for now

**Upload your files:**
4. Click **uploading an existing file** (link on the empty repo page)
5. Drag and drop ALL the files from the `job-app-system` folder Claude gave you
   - Make sure the folder structure is preserved: `frontend/`, `backend/`, etc.
6. Click **Commit changes**

---

## Step 3 — Create a Vercel account and deploy

Vercel hosts your web app for free.

1. Go to **vercel.com** → Click **Sign up** → Choose **Continue with GitHub**
2. Authorize Vercel to access your GitHub
3. Click **Add New Project**
4. Find your `jobpilot` repository → Click **Import**
5. Leave all settings as default → Click **Deploy**
6. Wait ~60 seconds — Vercel will give you a URL like `jobpilot-abc123.vercel.app`

🎉 Your web app is now live! But it needs API keys to work — next steps.

---

## Step 4 — Get your Anthropic API key (for AI features)

This is what powers the resume writing and job scoring.

1. Go to **console.anthropic.com** → Sign up for a free account
2. You get **$5 free credit** which covers hundreds of resume generations
3. Go to **API Keys** in the sidebar → Click **Create Key**
4. Copy the key (it starts with `sk-ant-...`) — save it somewhere safe

---

## Step 5 — Get a Serpapi key (for Google Jobs search)

Free tier = 100 searches/month (enough for daily fetching).

1. Go to **serpapi.com** → Click **Register**
2. Create a free account (no credit card needed for free tier)
3. Go to your **Dashboard** → copy your **API Key**

> **Note:** If you skip this step, the app will still work using Greenhouse job boards (completely free, no key needed), but you won't get Google Jobs results.

---

## Step 6 — Configure your Vercel environment variables

This is where you securely store your API keys.

1. Go to **vercel.com** → click your `jobpilot` project
2. Go to **Settings** → **Environment Variables**
3. Add these variables one by one (click **Add** for each):

| Name | Value | What it does |
|------|-------|--------------|
| `ANTHROPIC_API_KEY` | `sk-ant-your-key-here` | Powers AI resume writing |
| `SERPAPI_KEY` | `your-serpapi-key` | Fetches Google Jobs (optional) |
| `GREENHOUSE_COMPANIES` | `stripe,notion,figma,linear,vercel,anthropic` | Companies to check job boards for |

4. After adding all variables, go to **Deployments** → click the three dots on the latest deployment → **Redeploy**

---

## Step 7 — Upload your resume

1. Visit your app URL (e.g. `jobpilot-abc123.vercel.app`)
2. Click **⚙ Profile & Settings**
3. Fill in:
   - Your name
   - Target job titles (e.g. `Product Manager, Senior PM`)
   - Preferred locations (e.g. `Remote, New York`)
   - Minimum salary
   - Key skills
4. Upload your **resume PDF** using the upload area
5. Click **Save profile**

---

## Step 8 — Fetch your first jobs!

1. Click **↻ Fetch new jobs** in the top right
2. Wait 20-30 seconds while Claude finds and scores listings for you
3. Browse your personalized job cards — each shows a match percentage
4. Click **Approve** on any jobs you want to apply to
5. Claude will automatically generate a tailored resume + cover letter PDF
6. Download both files and apply!

---

## Keeping it running (optional automation)

To have new jobs fetched automatically every day without clicking the button:

1. In Vercel, go to your project → **Settings** → **Cron Jobs**
2. Add a cron job:
   - Path: `/api/fetch-jobs`
   - Schedule: `0 9 * * 1-5` (runs every weekday at 9am)

> Note: Vercel free tier includes 2 cron jobs/month. For daily fetching, the cheapest option is to simply click "Fetch new jobs" yourself when you want fresh listings — it only takes a second.

---

## Troubleshooting

**"Backend not connected" error:**
→ Check that your environment variables are set in Vercel and you redeployed after adding them.

**No jobs showing up:**
→ Make sure your profile has job titles filled in (e.g. "Product Manager")
→ Check that `GREENHOUSE_COMPANIES` lists companies that actually hire for your role

**Resume generation fails:**
→ Make sure `ANTHROPIC_API_KEY` is correct and you have API credits
→ Your $5 free credit = ~150 resume+cover letter pairs

**Want to change which companies are searched?**
→ Update the `GREENHOUSE_COMPANIES` environment variable in Vercel with a comma-separated list of company slugs (the part of their Greenhouse URL: `boards.greenhouse.io/COMPANYNAME`)

---

## Cost breakdown

| Service | Free tier | What you get |
|---------|-----------|--------------|
| GitHub | Forever free | Code storage |
| Vercel | Forever free | Hosting + deployments |
| Anthropic | $5 credit | ~150 resume generations |
| Serpapi | 100 searches/month | Google Jobs results |
| Greenhouse | Forever free | Company job boards |

**After your $5 Anthropic credit runs out:** You'll need to add a payment method and add credits. Resume generation costs roughly $0.03 per job (resume + cover letter). 100 applications ≈ $3.

---

*Built with Claude AI · JobPilot v1.0*
